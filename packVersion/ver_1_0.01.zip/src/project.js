require = function n(r, a, c) {
function l(t, e) {
if (!a[t]) {
if (!r[t]) {
var s = "function" == typeof require && require;
if (!e && s) return s(t, !0);
if (h) return h(t, !0);
var o = new Error("Cannot find module '" + t + "'");
throw o.code = "MODULE_NOT_FOUND", o;
}
var i = a[t] = {
exports: {}
};
r[t][0].call(i.exports, function(e) {
return l(r[t][1][e] || e);
}, i, i.exports, n, r, a, c);
}
return a[t].exports;
}
for (var h = "function" == typeof require && require, e = 0; e < c.length; e++) l(c[e]);
return l;
}({
ButtonScaler: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "5cc63s8F7lPCLT+AdcqP7mg", "ButtonScaler");
cc.Class({
extends: cc.Component,
properties: {
pressedScale: .9,
time: .1
},
onLoad: function() {
var e = this;
this.initScale = this.node.scale;
this.downAction = new cc.ScaleTo(this.time, this.pressedScale);
this.upAction = new cc.ScaleTo(this.time, this.initScale);
this.node.on(cc.Node.EventType.TOUCH_START, function() {
this.stopAllActions();
this.runAction(e.downAction);
this.opacity = 255;
return !0;
}, this.node);
this.node.on(cc.Node.EventType.TOUCH_END, function() {
this.stopAllActions();
this.runAction(e.upAction);
this.opacity = 255;
}, this.node);
this.node.on(cc.Node.EventType.TOUCH_CANCEL, function() {
this.stopAllActions();
this.runAction(e.upAction);
this.opacity = 255;
}, this.node);
this.node.on(cc.Node.EventType.TOUCH_MOVE, function() {}, this.node);
}
});
cc._RF.pop();
}, {} ],
ComUIBg: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "38322XPHb9FLKLi3XkrmCXr", "ComUIBg");
cc.Class({
extends: cc.Component,
properties: {
bgNode: {
displayName: "背景节点",
default: null,
type: cc.Node
}
},
onLoad: function() {
var e = cc.view.getVisibleSize().width, t = cc.view.getVisibleSize().height;
this.bgNode.width = e;
this.bgNode.height = t;
this.bgNode.on(cc.Node.EventType.MOUSE_ENTER, function(e) {
e.stopPropagation();
e.stopPropagationImmediate();
return !1;
}.bind(this));
this.bgNode.on(cc.Node.EventType.MOUSE_LEAVE, function(e) {
e.stopPropagation();
e.stopPropagationImmediate();
return !1;
}.bind(this));
this.bgNode.on(cc.Node.EventType.MOUSE_WHEEL, function(e) {
e.stopPropagation();
e.stopPropagationImmediate();
}.bind(this));
},
start: function() {},
addUI: function(e) {
var t = cc.instantiate(e);
t.x = t.y = 0;
this.node.addChild(t);
return t;
}
});
cc._RF.pop();
}, {} ],
DialogLayer: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "8b1b4Xrxh9G6KgL3qqWeYpU", "DialogLayer");
cc.Class({
extends: cc.Component,
properties: {
okBtn: {
displayName: "确定按钮",
default: null,
type: cc.Node
},
cancelBtn: {
displayName: "取消按钮",
default: null,
type: cc.Node
},
closeBtn: {
displayName: "关闭按钮",
default: null,
type: cc.Node
},
tipsLabel: {
displayName: "提示语",
default: null,
type: cc.Label
},
_okCb: null,
_cancelCb: null,
_closeCb: null
},
onLoad: function() {},
showTipsWithOkBtn: function(e, t, s, o) {
this.okBtn.active = !0;
this.cancelBtn.active = !1;
this.tipsLabel.string = e;
this._okCb = t;
this._cancelCb = s;
this._closeCb = o;
},
showTipsWithOkCancelBtn: function(e, t, s, o) {
this.okBtn.active = !0;
this.cancelBtn.active = !0;
this.tipsLabel.string = e;
this._okCb = t;
this._cancelCb = s;
this._closeCb = o;
},
setCloseBtnVisible: function(e) {
this.closeBtn.active = e;
},
onClickBtnOk: function() {
this._okCb && this._okCb();
this.node && this.node.destroy();
},
onClickBtnCancel: function() {
this._cancelCb && this._cancelCb();
this.node && this.node.destroy();
},
onClickBtnClose: function() {
this._closeCb && this._closeCb();
this.node.destroy();
}
});
cc._RF.pop();
}, {} ],
DialogMgr: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "49e1ba7Z/RCPLkkLRCNWLRp", "DialogMgr");
e("Util");
t.exports = {
showTipsWithOkBtn: function(i, n, r, a) {
var c = cc.director.getScene();
if (c) {
var l = cc.view.getVisibleSize().width, h = cc.view.getVisibleSize().height;
cc.loader.loadRes("prefab/dialog/DialogLayer", function(e, t) {
if (!e) {
var s = cc.instantiate(t);
s.x = l / 2;
s.y = h / 2;
c.addChild(s);
var o = s.getComponent("DialogLayer");
o && o.showTipsWithOkBtn(i, n, r, a);
}
});
}
},
showTipsWithOkCancelBtn: function(i, n, r, a, c) {
var l = cc.director.getScene();
if (l) {
var h = cc.view.getVisibleSize().width, g = cc.view.getVisibleSize().height;
cc.loader.loadRes("prefab/dialog/DialogLayer", function(e, t) {
if (!e) {
var s = cc.instantiate(t);
s.x = h / 2;
s.y = g / 2;
l.addChild(s);
var o = s.getComponent("DialogLayer");
o && o.showTipsWithOkCancelBtn(i, n, r, a);
c && c(s);
}
});
}
},
showTipsWithOkBtnAndNoCloseBtn: function(i, n, r, a) {
var c = cc.director.getScene();
if (c) {
var l = cc.view.getVisibleSize().width, h = cc.view.getVisibleSize().height;
cc.loader.loadRes("prefab/dialog/DialogLayer", function(e, t) {
if (!e) {
var s = cc.instantiate(t);
s.x = l / 2;
s.y = h / 2;
c.addChild(s);
var o = s.getComponent("DialogLayer");
if (o) {
o.showTipsWithOkBtn(i, n, r);
o.setCloseBtnVisible();
}
a && a(s);
}
});
}
}
};
cc._RF.pop();
}, {
Util: "Util"
} ],
GameLocalStorage: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "033a1DVjMVOeq/WP+wmvOA3", "GameLocalStorage");
t.exports = {
catchKey: "gameCatchKey",
catchData: {
curVer: "1.0",
newVer: "1.0",
localName: "",
localPwd: "",
userPhone: "",
visitorToken: null,
userToken: null,
musicVolume: 1,
effectVolume: 1,
noticeShowTime: null,
serverEnterCode: null
},
_isInit: !1,
initLocalStorage: function() {
if (!1 === this._isInit) {
this._isInit = !0;
var e = cc.sys.localStorage.getItem(this.catchKey);
if (e) {
var t = JSON.parse(e);
this.catchData.curVer = t.curVer;
this.catchData.newVer = t.newVer;
this.catchData.userPhone = t.userPhone;
this.catchData.visitorToken = t.visitorToken;
this.catchData.userToken = t.userToken;
this.catchData.musicVolume = void 0 === t.musicVolume ? 1 : t.musicVolume;
this.catchData.effectVolume = void 0 === t.effectVolume ? 1 : t.effectVolume;
this.catchData.noticeShowTime = void 0 === t.noticeShowTime ? new Date() : t.noticeShowTime;
this.catchData.serverEnterCode = t.serverEnterCode;
} else {
this.catchData.curVer = "1.0";
this.catchData.newVer = "1.0";
}
} else console.log("[GameLocalStorage] has init");
},
setServerEnterCode: function(e) {
this.catchData.serverEnterCode = e;
this._save();
},
getServerEnterCode: function() {
return this.catchData.serverEnterCode;
},
updateNoticeShowTime: function() {
this.catchData.noticeShowTime = new Date();
this._save();
},
_save: function() {
var e = JSON.stringify(this.catchData);
cc.sys.localStorage.setItem(this.catchKey, e);
},
getEffectVolume: function() {
var e = this.catchData.effectVolume;
void 0 === e && (e = 1);
return e;
},
getMusicVolume: function() {
var e = this.catchData.musicVolume;
void 0 === e && (e = 1);
return e;
},
setVolume: function(e, t) {
this.catchData.musicVolume = e;
this.catchData.effectVolume = t;
this._save();
},
setVersion: function(e, t) {
this.initLocalStorage();
this.catchData.curVer = e.toString();
this.catchData.newVer = t.toString();
this._save();
},
getCurVersion: function() {
this.initLocalStorage();
return this.catchData.curVer;
},
setLocalSaveNameAndPwd: function(e, t) {
this.catchData.localName = e;
this.catchData.localPwd = t;
this._save();
},
getLocalSaveName: function() {},
getLocalSavePwd: function() {},
setUserPhone: function(e) {
this.catchData.userPhone = e;
this._save();
},
getUserPhone: function() {
return this.catchData.userPhone;
},
setVisitorToken: function(e) {
this.catchData.visitorToken = e;
this._save();
},
getVisitorToken: function() {
return this.catchData.visitorToken;
},
setUserToken: function(e) {
this.catchData.userToken = e;
this._save();
},
getUserToken: function() {
return this.catchData.userToken;
}
};
cc._RF.pop();
}, {} ],
HelloWorld: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "280c3rsZJJKnZ9RqbALVwtK", "HelloWorld");
var o = e("Observer"), i = e("ObserverMgr");
cc.Class({
extends: o,
properties: {
label: {
default: null,
displayName: "",
type: cc.Label
}
},
onLoad: function() {
this.index = 0;
this._initMsg();
},
_getMsgList: function() {
return [ "dispatchMsg" ];
},
_onMsg: function(e, t) {
"dispatchMsg" === e && (this.label.string = t);
},
onBtnClickDispatchMsg: function() {
this.index++;
i.dispatchMsg("dispatchMsg", this.index);
},
onBtnClickDirect: function() {
cc.director.loadScene("Index");
},
update: function(e) {}
});
cc._RF.pop();
}, {
Observer: "Observer",
ObserverMgr: "ObserverMgr"
} ],
HotUpdateModule: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "3bb24JQqU1G07rocq58W6a1", "HotUpdateModule");
t.exports = {
Msg: {
OnUpdateProgress: "HotUpdateModule_Msg_OnUpdateProgress",
OnGetVersionInfo: "HotUpdateModule_Msg_OnGetVersionInfo",
OnTipUpdateVersion: "HotUpdateModule_Msg_OnTipUpdateVersion",
OnUpdateVersionResult: "HotUpdateModule_Msg_OnUpdateVersionResult"
}
};
cc._RF.pop();
}, {} ],
HotUpdateScene: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "fb5bcZRYBRDNI3UvstSh+EL", "HotUpdateScene");
var o = e("HotUpdate"), i = e("Observer"), n = e("Util"), r = e("DialogMgr"), a = e("HotUpdateModule");
cc.Class({
extends: i,
properties: {
manifest: cc.RawAsset,
versionLabel: {
default: null,
displayName: "版本号",
type: cc.Label
},
updateProgress: {
displayName: "热更新进度条",
default: null,
type: cc.ProgressBar
},
tipsLabel: {
displayName: "消息提示",
default: null,
type: cc.Label
},
addNode: {
displayName: "添加节点",
default: null,
type: cc.Node
}
},
_onMsg: function(e, t) {
if (e === a.Msg.OnUpdateVersionResult) if (t) {
this.tipsLabel.string = "更新成功";
n.log("更新成功");
this._onShowDownLoadUpdateVersionResult(!0);
} else {
this.tipsLabel.string = "更新失败";
n.log("热更新失败");
this._onShowDownLoadUpdateVersionResult(!1);
} else if (e === a.Msg.OnUpdateProgress) {
console.log("[update]: 进度=" + t.fileProgress);
this.updateProgress.progress = t.fileProgress;
this.tipsLabel.string = "正在更新中,请耐心等待";
console.log(t.msg);
} else if (e === a.Msg.OnTipUpdateVersion) if (t === jsb.EventAssetsManager.NEW_VERSION_FOUND) this._onShowNoticeUpdateLayer(); else if (t === jsb.EventAssetsManager.ALREADY_UP_TO_DATE) {
n.log("版本一致,无需更新,进入游戏中...");
this._enterGame();
} else this._onShowNoticeCheckVersionFailed(); else e === a.Msg.OnGetVersionInfo && this._updateVersionView(t.curVer, t.newVersion);
},
_updateVersionView: function(e, t) {
this.versionLabel.string = "服务器版本号: " + t + ",本地版本:" + e;
},
_getMsgList: function() {
return [ a.Msg.OnGetVersionInfo, a.Msg.OnTipUpdateVersion, a.Msg.OnUpdateProgress, a.Msg.OnUpdateVersionResult ];
},
onLoad: function() {
this._initMsg();
this._initView();
this._checkUpdate();
this._initVersionFlag();
},
_initVersionFlag: function() {},
_onShowNoticeUpdateLayer: function() {
n.log("提示更新");
r.showTipsWithOkBtn("检测到新版本,点击确定开始更新", function() {
o.hotUpdate();
}.bind(this));
},
_onShowNoticeCheckVersionFailed: function() {
n.log("检查更新失败");
r.showTipsWithOkBtn("检查更新失败,点击重试", function() {
o.checkUpdate();
}.bind(this));
},
_onShowDownLoadUpdateVersionResult: function(e) {
e ? r.showTipsWithOkBtn("更新成功,点击确定重启游戏", function() {
cc.audioEngine.stopAll();
cc.game.restart();
}.bind(this)) : r.showTipsWithOkBtn("更新失败,点击重试", function() {
o.checkUpdate();
}.bind(this));
},
_initView: function() {
this.tipsLabel.string = "";
this.versionLabel.string = "";
this.updateProgress.progress = 0;
this.addNode.destroyAllChildren();
},
_checkUpdate: function() {
if (cc.sys.isNative) {
if (this.manifest) {
var e = "正在获取版本...";
this.tipsLabel.string = e;
n.log(e);
o.init(this.manifest);
o.checkUpdate();
}
} else {
n.log("web 平台不需要热更新");
this._enterGame();
}
},
onBtnClickCheckUpdate: function() {
this._checkUpdate();
},
_enterGame: function() {
n.log("进入游戏成功");
this.updateProgress.node.active = !1;
cc.director.loadScene("HelloWorld");
}
});
cc._RF.pop();
}, {
DialogMgr: "DialogMgr",
HotUpdate: "HotUpdate",
HotUpdateModule: "HotUpdateModule",
Observer: "Observer",
Util: "Util"
} ],
HotUpdate: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "3c083vkHGxHfKDu2z9Cbmt9", "HotUpdate");
var a = e("ObserverMgr"), c = e("HotUpdateModule");
t.exports = {
_assetsMgr: null,
_checkListener: null,
_updateListener: null,
_compareVersion: function(e, t) {
console.log("客户端版本: " + e + ", 当前最新版本: " + t);
a.dispatchMsg(c.Msg.OnGetVersionInfo, {
curVer: e,
newVersion: t
});
for (var s = e.split("."), o = t.split("."), i = 0; i < s.length; ++i) {
var n = parseInt(s[i]), r = parseInt(o[i] || 0);
if (n !== r) return n - r;
}
return o.length > s.length ? -1 : 0;
},
reCheckVersion: function() {
this._assetsMgr.downloadFailedAssets();
},
checkUpdate: function() {
if (this._assetsMgr.getLocalManifest().isLoaded()) {
if (null !== this._checkListener) {
cc.eventManager.removeListener(this._checkListener);
this._checkListener = null;
}
this._checkListener = new jsb.EventListenerAssetsManager(this._assetsMgr, this._checkCallBack.bind(this));
cc.eventManager.addListener(this._checkListener, 1);
console.log("[HotUpdate] checkUpdate");
this._assetsMgr.checkUpdate();
} else console.log("加载本地 manifest 失败 ...");
},
_checkCallBack: function(e) {
cc.log("热更新检查结果: " + e.getEventCode());
for (var t = this._assetsMgr.getRemoteManifest().getSearchPaths(), s = 0; s < t.length; s++) {
t[s];
console.log(JSON.stringify(t[s]));
}
var o = e.getEventCode();
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("没有发现本地的manifest, 跳过热更新.");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
console.log("下载 manifest 失败, 跳过热更新.");
break;

case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("解析 manifest 失败, 跳过热更新.");
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("已经和远程版本一致");
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
console.log("发现新版本,请更新");
break;

default:
return;
}
if (null !== this._checkListener) {
cc.eventManager.removeListener(this._checkListener);
this._checkListener = null;
}
a.dispatchMsg(c.Msg.OnTipUpdateVersion, o);
},
hotUpdate: function() {
if (this._assetsMgr) {
this._updateListener = new jsb.EventListenerAssetsManager(this._assetsMgr, this._hotUpdateCallBack.bind(this));
cc.eventManager.addListener(this._updateListener, 1);
this._assetsMgr.update();
}
},
_hotUpdateCallBack: function(e) {
console.log("hotUpdate Code: " + e.getEventCode());
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("没有发现本地的 manifest, 跳过热更新.");
this._onUpdateFailed();
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var t = {}, s = e.getPercentByFile();
s || (s = 0);
t.fileProgress = s.toFixed(2) || 1;
t.byteProgress = e.getPercent().toFixed(2);
t.msg = "";
var o = e.getMessage();
if (o) {
console.log("Updated file: " + o);
cc.log(e.getPercent().toFixed(2) + "% : " + o);
t.msg = o;
}
a.dispatchMsg(c.Msg.OnUpdateProgress, t);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("下载 manifest 失败, 跳过热更新.");
this._onUpdateFailed();
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("已经和远程版本一致 ");
this._onUpdateFailed();
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
console.log("更新完成 " + e.getMessage());
this._onUpdateFinished();
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
console.log("更新失败. " + e.getMessage());
this._onUpdateFailed();
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
console.log("资源更新发生错误: " + e.getAssetId() + ", " + e.getMessage());
this._onUpdateFailed();
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
console.log(e.getMessage());
this._onUpdateFailed();
}
},
_onUpdateFailed: function() {
if (null !== this._updateListener) {
cc.eventManager.removeListener(this._updateListener);
this._updateListener = null;
}
a.dispatchMsg(c.Msg.OnUpdateVersionResult, !1);
},
_onUpdateFinished: function() {
if (null !== this._updateListener) {
cc.eventManager.removeListener(this._updateListener);
this._updateListener = null;
}
var e = jsb.fileUtils.getSearchPaths(), t = this._assetsMgr.getLocalManifest().getSearchPaths();
console.log(JSON.stringify(t));
Array.prototype.unshift(e, t);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(e));
jsb.fileUtils.setSearchPaths(e);
a.dispatchMsg(c.Msg.OnUpdateVersionResult, !0);
},
removeTmpManifestFile: function(e) {},
removeFile: function(e) {
if (jsb.fileUtils.isFileExist(e)) {
jsb.fileUtils.removeFile(e);
jsb.fileUtils.isFileExist(e) ? console.log("[HotUpdate] remove file failed: " + e) : console.log("[HotUpdate] remove file success: " + e);
} else console.log("[HotUpdate] file not exist: " + e);
},
removeTempDir: function(e) {
var t = e + "_temp";
this.removeDirectory(t);
},
removeDirectory: function(e) {
if (jsb.fileUtils.isDirectoryExist(e)) {
jsb.fileUtils.removeDirectory(e);
jsb.fileUtils.isDirectoryExist(e) ? console.log("[HotUpdate] removeDir failed: " + e) : console.log("[HotUpdate] removeDir success: " + e);
} else console.log("[HotUpdate] dir not exist: " + e);
},
init: function(e) {
if (cc.sys.isNative) {
var t = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-asset";
console.log("热更新资源存放路径 : " + t);
console.log("本地 manifest 路径 : " + e);
this._assetsMgr = new jsb.AssetsManager(e, t);
cc.sys.ENABLE_GC_FOR_NATIVE_OBJECTS || this._assetsMgr.retain();
console.log("[HotUpdate] local packageUrl:" + this._assetsMgr.getLocalManifest().getPackageUrl());
console.log("[HotUpdate] project.manifest remote url:" + this._assetsMgr.getLocalManifest().getManifestFileUrl());
console.log("[HotUpdate] version.manifest remote url:" + this._assetsMgr.getLocalManifest().getVersionFileUrl());
this._assetsMgr.setVersionCompareHandle(this._compareVersion.bind(this));
this._assetsMgr.setVerifyCallback(function(e, t) {
t.compressed, t.md5, t.path, t.size;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._assetsMgr.setMaxConcurrentTask(10);
}
}
};
cc._RF.pop();
}, {
HotUpdateModule: "HotUpdateModule",
ObserverMgr: "ObserverMgr"
} ],
Index: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "f53a5tmKA1If50wuASG32MX", "Index");
cc.Class({
extends: cc.Component,
properties: {},
onLoad: function() {},
onBtnClickDirect: function() {
cc.director.loadScene("HelloWorld");
}
});
cc._RF.pop();
}, {} ],
LogViewItem: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "be9647MsTRK4JDhNnyYZAii", "LogViewItem");
cc.Class({
extends: cc.Component,
properties: {
word: {
displayName: "提示语",
default: null,
type: cc.Label
}
},
onLoad: function() {},
start: function() {},
runLogAction: function(e) {
this.word.string = e;
var t = cc.delayTime(2), s = cc.removeSelf(!0), o = cc.sequence([ t, s ]);
this.node.runAction(o);
}
});
cc._RF.pop();
}, {} ],
LogView: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "eb182sjYsxMFZGOjfhiLfL8", "LogView");
cc.Class({
extends: cc.Component,
properties: {
logNode: {
displayName: "log节点",
default: null,
type: cc.Node
},
logItem: {
displayName: "item",
default: null,
type: cc.Prefab
}
},
onLoad: function() {},
start: function() {},
addLog: function(e) {
var t = cc.instantiate(this.logItem);
this.logNode.addChild(t);
var s = t.getComponent("LogViewItem");
s && s.runLogAction(e);
}
});
cc._RF.pop();
}, {} ],
NetHttpMgr: [ function(a, e, t) {
"use strict";
cc._RF.push(e, "28bb7Pxx3xE0KormXdxwQsr", "NetHttpMgr");
var c = a("ObserverMgr"), s = a("DialogMgr");
e.exports = {
_tmpQuest: {
msg: null,
data: null
},
quest: function(e, t) {
var s = a("Util").getClientType(), o = a("GameLocalStorage").getCurVersion();
t.clientType = s;
t.version = o;
t.channel = "123";
this._tmpQuest.msg = e;
this._tmpQuest.data = t;
this._showSendData(e, t);
var r = new XMLHttpRequest();
r.ontimeout = this._onTimeout.bind(this);
r.timeout = 6e3;
r.onreadystatechange = function() {
if (4 === r.readyState && 200 <= r.status && r.status < 400) {
var e = r.responseText, t = JSON.parse(e);
c.dispatchMsg(GameMsgGlobal.Net.Recv, t);
var s = t[0], o = t[1], i = t[2], n = GameMsgHttp.getMsgById(s);
this._showRecvData(n, o, i);
void 0 !== o && null !== n ? o === GameMsgGlobal.NetCode.SuccessHttp.id ? c.dispatchMsg(n, i) : c.dispatchMsg(GameMsgGlobal.Net.MsgErr, t) : console.log("[Http] 缺少code字段");
}
}.bind(this);
r.onerror = function(e) {
this._onTimeout();
}.bind(this);
var i = {
msg_id: e.id,
data: t
}, n = JSON.stringify(i);
r.open("post", url, !0);
c.dispatchMsg(GameMsgGlobal.Net.Send, null);
try {
r.send(n);
} catch (e) {
console.log("网络超时");
}
},
_showRecvData: function(e, t, s) {
var o = {
time: this._getTime(),
msg: e,
code: t,
data: s
};
cc.sys.isBrowser ? console.log("[Http<===]%c %s", "color:blue;font-weight:bold;", JSON.stringify(o)) : console.log("[Http<===]%s", JSON.stringify(o));
},
_showSendData: function(e, t) {
var s = t, o = e.msg, i = {
time: this._getTime(),
msg: o,
msgID: e.id,
data: s
};
cc.sys.isBrowser ? console.log("[Http===>]%c %s ", "color:green;font-weight:bold;", JSON.stringify(i)) : console.log("[Http===>]%s ", JSON.stringify(i));
},
_getTime: function() {
var e = new Date();
return e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
},
_onTimeout: function() {
console.log("[HTTP] %c连%c接%c超%c时", "color:red", "color:orange", "color:purple", "color:green");
c.dispatchMsg(GameMsgGlobal.Net.TimeOut, null);
s.showTipsWithOkBtnAndNoCloseBtn("网络连接失败,是否重试?", function() {
var e = this._tmpQuest.msg, t = this._tmpQuest.data;
null !== e && null !== t && this.quest(e, t);
}.bind(this), null, function(e) {
a("Util").reZorderToTop(e);
});
}
};
cc._RF.pop();
}, {
DialogMgr: "DialogMgr",
GameLocalStorage: "GameLocalStorage",
ObserverMgr: "ObserverMgr",
Util: "Util"
} ],
NetSocketMgr: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "8f4feeTQ/xBWZy9wfXQ1UR0", "NetSocketMgr");
var a = e("ObserverMgr");
e("Util");
t.exports = {
ws: null,
isNetOpen: !1,
heartID: null,
init: function() {
if (null === this.ws) {
console.log("[Socket] con url:" + url);
this.ws = new WebSocket("192");
this.ws.onopen = this.onOpen.bind(this);
this.ws.onmessage = this.onMessage.bind(this);
this.ws.onerror = this.onError.bind(this);
this.ws.onclose = this.onClose.bind(this);
} else console.log("[Socket] has init");
},
_onHeartBeat: function() {
this.ws && (this.ws.readyState, WebSocket.OPEN);
},
_beganHeartBeat: function() {
this._cleanHeartBeat();
this.heartID = setInterval(this._onHeartBeat.bind(this), 3e4);
},
_cleanHeartBeat: function() {
if (null !== this.heartID) {
clearInterval(this.heartID);
this.heartID = null;
}
},
onOpen: function() {
console.log("[Socket] Open: " + this._getTime());
this.isNetOpen = !0;
a.dispatchMsg(GameMsgGlobal.Net.Open, null);
this._beganHeartBeat();
},
onError: function() {
console.log("[Socket] Error: " + this._getTime());
this.ws = null;
this.isNetOpen = !1;
a.dispatchMsg(GameMsgGlobal.Net.Error, null);
this._cleanHeartBeat();
},
onClose: function() {
console.log("[Socket] Close: " + this._getTime());
a.dispatchMsg(GameMsgGlobal.Net.Close, null);
this.ws = null;
this.isNetOpen = !1;
this._cleanHeartBeat();
this.init();
},
onMessage: function(e) {
var t = null;
try {
t = JSON.parse(e.data);
} catch (e) {
t = null;
}
if (null !== t) {
var s = t[0], o = GameMsgSocket.getRecvDataByCode(s);
if (o) {
var i = t[1], n = t[2];
this._showRecvData(o.msg, t);
a.dispatchMsg(GameMsgGlobal.Net.Recv, t);
if (void 0 === i) console.log("[SocketMgr] 缺少Code字段"); else if (0 === i) o && a.dispatchMsg(o.msg, n); else {
console.log("[SocketMgr] netData 错误码: " + i);
var r = t.msg;
a.dispatchMsg(GameMsgGlobal.Net.MsgErr, [ i, o.msg, n, r ]);
}
} else console.log("[SocketMgr] 客户端未发现网络配置: " + e.data);
} else console.log("[Socket] 服务器返回数据不是json格式: " + e.data);
},
send: function(e, t) {
if (this.ws) if (this.ws.readyState === WebSocket.OPEN) {
var s = [ e.code, t ];
this._showSendData(e.msg, t);
this.ws.send(JSON.stringify(s));
} else console.log("[Socket] 网络失去连接"); else console.log("网络连接出现问题:可能没有初始化网络,或网络失去连接!");
},
_showSendData: function(e, t) {
var s = t, o = e.msg, i = {
time: this._getTime(),
msg: o,
data: s
};
cc.sys.isBrowser ? console.log("[Socket===>]%c %s ", "color:green;font-weight:bold;", JSON.stringify(i)) : console.log("[Socket===>]%s ", JSON.stringify(i));
},
_showRecvData: function(e, t) {
var s = {
time: this._getTime(),
msg: e,
data: t
};
cc.sys.isBrowser ? console.log("[Socket<===]%c %s", "color:red;font-weight:bold;", JSON.stringify(s)) : console.log("[Socket<===]%s", JSON.stringify(s));
},
_getTime: function() {
var e = new Date();
return e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
}
};
cc._RF.pop();
}, {
ObserverMgr: "ObserverMgr",
Util: "Util"
} ],
ObserverMgr: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "e92c72NcxhJx5iFdLtdqt/A", "ObserverMgr");
t.exports = {
obsArray: {},
addEventListener: function(e, t, s) {
"undefined" == typeof s && console.log("[ObserverMgr] 注册消息 [%s]:%s 的作用于未定义", e, t.name);
"undefined" == typeof this.obsArray[e] && (this.obsArray[e] = []);
for (var o = 0; o < this.obsArray[e].length; o++) {
var i = this.obsArray[e][o];
if (i.func === t && i.ob === s) return;
}
this.obsArray[e].push({
func: t,
ob: s
});
},
removeEventListener: function(e, t, s) {
var o = !1, i = this.obsArray[e];
if (i) for (var n = 0; n < i.length; ) {
var r = i[n], a = r.func, c = r.ob;
if (t === a && s === c) {
i.splice(n, 1);
o = !0;
} else n++;
}
return o;
},
removeEventListenerWithMsg: function(e) {
var t = this.obsArray[e];
if (t) for (var s = 0; s < t.length; s++) t.splice(s, 1);
},
removeEventListenerWithObject: function(e) {
for (var t in this.obsArray) for (var s = this.obsArray[t], o = 0; o < s.length; ) {
s[o].ob === e ? s.splice(o, 1) : o++;
}
},
cleanAllEventListener: function() {
this.obsArray = {};
},
dispatchMsg: function(e, t) {
var s = this.obsArray[e];
if ("undefined" != typeof s) for (var o = 0; o < s.length; o++) {
var i = s[o], n = i.func, r = i.ob;
n && r && n.apply(r, [ e, t ]);
} else console.log("消息列表中不存在: " + e);
}
};
cc._RF.pop();
}, {} ],
Observer: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "2ab8eVyRspHdJWrPlYr1Egp", "Observer");
var o = e("ObserverMgr");
cc.Class({
extends: cc.Component,
_initMsg: function() {
for (var e = this._getMsgList(), t = 0; t < e.length; t++) {
var s = e[t];
o.addEventListener(s, this._onMsg, this);
}
},
onLoad: function() {},
_getMsgList: function() {
return [];
},
_onMsg: function(e, t) {},
_onError: function(e, t, s) {},
_onNetOpen: function() {},
_onErrorDeal: function(e, t) {
var s = t[0], o = t[1], i = t[2];
this._onError(s, o, i);
},
onDisable: function() {
o.removeEventListenerWithObject(this);
},
onEnable: function() {},
onDestroy: function() {
o.removeEventListenerWithObject(this);
}
});
cc._RF.pop();
}, {
ObserverMgr: "ObserverMgr"
} ],
Tips: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "534b8bkZKFE1qSf7u0IJi2O", "Tips");
t.exports = {
_logView: null,
show: function(i) {
this._logView && !1 === this._logView.isValid && (this._logView = null);
if (null === this._logView) {
var n = cc.director.getScene();
if (n) {
var r = cc.view.getVisibleSize().width, a = cc.view.getVisibleSize().height;
cc.loader.loadRes("prefab/log/LogView", function(e, t) {
if (!e) {
var s = cc.instantiate(t);
s.x = r / 2;
s.y = a / 2;
n.addChild(s);
var o = s.getComponent("LogView");
o && (this._logView = o).addLog(i);
}
}.bind(this));
}
} else {
var e = this._logView.node.parent.children.length;
this._logView.addLog(i);
this._logView.node.setLocalZOrder(e);
}
}
};
cc._RF.pop();
}, {} ],
UIMgr: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "7fff1Pn665PRISUtHP/Z26r", "UIMgr");
t.exports = {
_uiMap: {},
createPrefab: function(r, a) {
r ? cc.loader.loadRes("prefab/ComUIBg", function(e, t) {
if (e) console.log(e.errorMessage); else {
var s = cc.instantiate(t), o = s.getComponent("ComUIBg");
if (o) {
var i = o.addUI(r), n = i.uuid.toString();
this._uiMap[n] = s;
a && a(s, i);
}
}
}.bind(this)) : console.log("[UIMgr] 无法创建Prefab: " + r);
},
createPrefabAddToRunningScene: function(l, h) {
l ? cc.loader.loadRes("prefab/ComUIBg", function(e, t) {
var s = cc.instantiate(t), o = s.getComponent("ComUIBg");
if (o) {
var i = o.addUI(l), n = i.uuid.toString();
this._uiMap[n] = s;
var r = cc.director.getScene();
if (r) {
var a = cc.view.getVisibleSize().width, c = cc.view.getVisibleSize().height;
s.x = a / 2;
s.y = c / 2;
r.addChild(s);
h && h(i);
} else console.log("[UIMgr] 没有运行Scene,无法添加UI界面!");
}
}.bind(this)) : console.log("[UIMgr] 无法创建Prefab: " + l);
},
destroyUI: function(e) {
if (e) if (e.node) {
var t = e.node.uuid.toString(), s = this._uiMap[t];
if (s) {
s.destroy();
this._uiMap[t] = null;
} else console.log("[UIMgr]界面不是UIMgr创建的,无法销毁:" + e.node.name);
} else console.log("[UIMgr] " + e.name + " 没有node属性"); else console.log("[UIMgr] 缺少参数");
}
};
cc._RF.pop();
}, {} ],
Util: [ function(e, t, s) {
"use strict";
cc._RF.push(t, "08ce3tyQidD1p66cpyoKlmR", "Util");
var l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
return typeof e;
} : function(e) {
return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};
t.exports = {
log: function(e) {
console.log("-------------------------------------------");
console.log(e);
console.log("*******************************************");
},
prefix: function(e, t) {
return e.toString().length >= t ? e : (Array(t).join("0") + e).slice(-t);
},
formatTimeRemainTime: function(e) {
var t = parseInt(e / 1e3), s = Math.floor(t / 3600), o = Math.floor(t % 3600 / 60), i = Math.floor(t % 3600 % 60);
return (s = this.prefix(s, 2)) + ":" + (o = this.prefix(o, 2)) + ":" + (i = this.prefix(i, 2));
},
randomByMaxValue: function(e) {
return Math.floor(Math.random() * e);
},
randomByMinToMax: function(e, t) {
return Math.floor(Math.random() * (t - e)) + e;
},
removeElementsFromArray: function(e, t) {
for (var s = -1, o = e.length, i = 0; i < o; i++) if (e[i] === t) {
s = i;
break;
}
0 <= s && e.splice(s, 1);
},
makeRdmStr: function(e) {
e = e || 32;
for (var t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", s = t.length, o = "", i = 0; i < e; i++) o += t.charAt(Math.floor(Math.random() * s));
return o;
},
numCutOut: function(e, t) {
var s = (parseInt(e * Math.pow(10, t)) / Math.pow(10, t)).toString(), o = s.split(".");
if (1 === o.length) {
s += ".";
for (var i = 0; i < t; i++) s += "0";
} else if (2 === o.length) for (var n = o[1].length; n < t; n++) s += "0";
return s;
},
getUnixTime: function() {
return Math.round(new Date().getTime() / 1e3);
},
deepCopy: function(e) {
for (var t = [], s = 0, o = e.length; s < o; s++) e[s] instanceof Array ? t[s] = this.deepCopy(e[s]) : t[s] = e[s];
return t;
},
getRandomItemFromArray: function(e, t) {
var s = [];
for (var o in e) s.push(e[o]);
for (var i = [], n = 0; n < t && 0 < s.length; n++) {
var r = Math.floor(Math.random() * s.length);
i[n] = s[r];
s.splice(r, 1);
}
return i;
},
getMaxFromArray: function(e) {
return Math.max.apply(null, e);
},
getMaxCbFromArray: function(e, t) {
this.assert(1 <= e.length);
for (var s = t(e[0]), o = 0, i = 1; i < e.length; ++i) {
var n = t(e[i]);
if (s < n) {
s = n;
o = i;
}
}
return e[o];
},
getFiltedArray: function(e, t) {
var s = [], o = !0, i = !1, n = void 0;
try {
for (var r, a = e[Symbol.iterator](); !(o = (r = a.next()).done); o = !0) {
var c = r.value;
t(c) && s.push(c);
}
} catch (e) {
i = !0;
n = e;
} finally {
try {
!o && a.return && a.return();
} finally {
if (i) throw n;
}
}
return s;
},
getNowTime: function() {
var e = new Date();
return e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
},
getIP: function() {
var e = new XMLHttpRequest();
e.onreadystatechange = function() {
4 === e.readyState && 200 <= e.status && e.status < 400 && console.log(e.responseText);
};
e.open("GET", "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js", !0);
e.send();
},
getClientType: function() {},
reZorderToTop: function(e) {
var t = e.parent.children.length;
e.setLocalZOrder(t);
},
assert: function(e) {
e || ("chrome" === cc.sys.browserType ? alert("error occurs, please open chrome debugger tools and retry ") : "firefox" === cc.sys.browserType ? alert("error occurs, please open firefox debugger tools and debug") : "safari" === cc.sys.browserType ? alert("error occurs, please open safari debugger tools and debug") : console.log("not support browserType: ", cc.sys.browserType));
},
print_tree: function(e) {
console.log("=============print_tree begin ===========");
(function e(t, s) {
if (!(5 <= s)) {
for (var o = "", i = 0; i < s; ++i) o += "    ";
var n = o + "    ";
for (var r in t) {
var a = "值无法查看", c = "类型无法查看";
try {
a = t[r];
c = l(t[r]);
} catch (e) {}
console.log(o, r);
if ("object" == c) {
console.log(n, "type:", c);
console.log(n, "value: {");
e(t[r], s + 1);
console.log(n, "}");
} else {
console.log(n, "type:", c);
console.log(n, "value:", a);
}
}
if (t.prototype) {
console.log(o, "prototype: {");
e(t.prototype, s + 1);
console.log(o, "}");
}
}
})(e, 0);
console.log("=============print_tree end  ============");
}
};
cc._RF.pop();
}, {} ]
}, {}, [ "HelloWorld", "Index", "HotUpdate", "HotUpdateModule", "Observer", "ObserverMgr", "NetHttpMgr", "NetSocketMgr", "ButtonScaler", "ComUIBg", "DialogMgr", "Tips", "UIMgr", "Util", "GameLocalStorage", "HotUpdateScene", "DialogLayer", "LogView", "LogViewItem" ]);