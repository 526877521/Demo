window.__require = function o(e, t, c) {
function r(l, n) {
if (!t[l]) {
if (!e[l]) {
var i = l.split("/");
i = i[i.length - 1];
if (!e[i]) {
var a = "function" == typeof __require && __require;
if (!n && a) return a(i, !0);
if (s) return s(i, !0);
throw new Error("Cannot find module '" + l + "'");
}
l = i;
}
var u = t[l] = {
exports: {}
};
e[l][0].call(u.exports, function(o) {
return r(e[l][1][o] || o);
}, u, u.exports, o, e, t, c);
}
return t[l].exports;
}
for (var s = "function" == typeof __require && __require, l = 0; l < c.length; l++) r(c[l]);
return r;
}({
HelloWorld: [ function(o, e, t) {
"use strict";
cc._RF.push(e, "280c3rsZJJKnZ9RqbALVwtK", "HelloWorld");
cc.Class({
extends: cc.Component,
properties: {
label: {
default: null,
type: cc.Label
},
envLabel: {
default: null,
type: cc.Label
},
text: "Hello, World!"
},
onLoad: function() {
this.envLabel.string = cc.sys.os;
console.log("进入到游戏中", cc.sys.os);
if (cc.sys.os === cc.sys.OS_ANDROID) {
var o = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/JsbManager", "getNum", "(I)I", 5);
console.log("返回的数据是", o);
cc.log("333333333333333333333");
this.label.string = o + "";
var e = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/JsbManager", "isAndroidSimulator", "()Z");
console.log("是否是模拟器", e);
cc.log("55555555555555555555555");
this.label.string = e + "";
} else cc.sys.os === cc.sys.OS_IOS || cc.sys.os === cc.sys.OS_OSX ? this.label.string = "苹果系统" : this.label.string = "浏览器";
},
onBtnWxLogin: function() {
console.log("点击微信登录");
},
update: function(o) {}
});
cc._RF.pop();
}, {} ]
}, {}, [ "HelloWorld" ]);